//
//  ViewController.swift
//  torathna
//
//  Created by haya on 7/11/20.
//  Copyright © 2020 haya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

        override func viewDidLoad() {
            super.viewDidLoad()
            self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
    }
    
    
}
