//
//  info.swift
//  torathna
//
//  Created by haya on 7/19/20.
//  Copyright © 2020 haya. All rights reserved.
//

import Foundation
 
var switchIsOn = true

