//
//  place.swift
//  torathna
//
//  Created by haya on 7/12/20.
//  Copyright © 2020 haya. All rights reserved.
//

import Foundation

struct placeModel {
    var placeName : String
    var object : String
    var textInfo : String
    var backgroundImage : String
   
}
var PlacesData = [
    placeModel(placeName: "البحر", object: "البوم", textInfo: "سفينة كويتية قديمة", backgroundImage: "ocean"),
placeModel(placeName: "البيت", object: "دامة", textInfo: "لعبة كويتية قديمة ", backgroundImage: "home2"),
placeModel(placeName: "السوق", object: "خياطة", textInfo: "حرفة", backgroundImage: "home2")

]

